﻿// Program 1A
// CIS 200-01
// Due: 10/11/16
// Grading ID: C1814

// File: Package.cs
// This derives class Package from Parcel, and adds length, width, height, and weight

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class Package : Parcel
{

    private double _length;      // Backing field to hold length of package
    private double _width;       // Backing field to hold width of package
    private double _height;      // Backing field to hold height of package
    private double _weight;      // Backing field to hold weight of package

    // Precondition: None
    // Postcondition: Package created with values for origin address, destination address,
    //                length, width, height, and weight
    public Package(Address originAddress, Address destAddress, double plength,
        double pwidth, double pheight, double pweight) : base(originAddress, destAddress)
    {
        Length = plength;
        Width = pwidth;
        Height = pheight;
        Weight = pweight;
    }

    public double Length
    {
        // Precondition: None
        // Postcondition: Package's length returned
        get
        {
            return _length;
        }

        // Precondition: None
        // Postcondition: Package's length set to specified value
        set
        {
            if (_length >= 0)
                _length = value;
            else
                throw new ArgumentOutOfRangeException("Length", value,
                    "Length must be greater than 0");
        }
    }

    public double Width
    {
        // Precondition: None
        // Postcondition: Package's width returned
        get
        {
            return _width;
        }

        // Precondition: None
        // Postcondition: Package's width set to specified value
        set
        {
            if (_width >= 0)
                _width = value;
            else
                throw new ArgumentOutOfRangeException("Width", value,
                    "Width must be greater than 0");
        }
    }

    public double Height
    {
        // Precondition: None
        // Postcondition: Package's height returned
        get
        {
            return _height;
        }


        // Precondition: None
        // Postcondition: Package's height set to specified value
        set
        {
            if (_height >= 0)
                _height = value;
            else
                throw new ArgumentOutOfRangeException("Height", value,
                    "Height must be greater than 0");
        }
    }

    public double Weight
    {

        // Precondition: None
        // Postcondition: Package's weight returned
        get
        {
            return _weight;
        }

        // Precondition: None
        // Postcondition: Package's weight set to specified value
        set
        {
            if (Weight >= 0)
                _weight = value;
            else
                throw new ArgumentOutOfRangeException("Weight", value,
                    "Weight must be greater than 0");
        }
    }

    // Precondition:  None
    // Postcondition: A string with the letter's data has been returned
    public override string ToString()
    {
        return String.Format("Origin Address:{6}{0}{6}{6}Destination Address:{6}{1}{6}{6}Length:{2}{6}Width:{3}{6}Height:{4}{6}Weight:{5}{6}",
            OriginAddress, DestinationAddress, Length, Width, Height, Weight, Environment.NewLine);
    }
}