﻿// Program 1A
// CIS 200-01
// Due: 10/11/16
// Grading ID: C1814

// File: GroundPackage.cs
// This class is a derived class of Parcel, creates method ZoneDistance to ocalculate
// distance travelled by the GroundPackage object

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class GroundPackage : Package
{
    // Precondition: None
    // Postcondition: GroundPackage created with values for origin address, destination address,
    //                length, width, height, and weight
    public GroundPackage(Address originAddress, Address destAddress, double length, double width,
      double height, double weight) : base(originAddress, destAddress, length, width, height, weight)
    {
        // No new data to initialize
    }

    // Precondition: Origin and destination addresses have valid zip codes
    // Postcondition: Zone distance is returned
    public int ZoneDistance
    {
        // Precondition:  None
        // Postcondition: The ground package's zone distance is returned.
        //                The zone distance is the positive difference between the
        //                first digit of the origin zip code and the first
        //                digit of the destination zip code.
        get
        {
            const int FIRST_DIGIT_FACTOR = 10000; // Denominator to extract 1st digit
            int dist;                             // Calculated zone distance

            dist = Math.Abs((OriginAddress.Zip / FIRST_DIGIT_FACTOR) - (DestinationAddress.Zip / FIRST_DIGIT_FACTOR));

            return dist;
        }
    }

    // Precondition:  None
    // Postcondition: The GroundPackage's cost has been returned
    public override decimal CalcCost()
    {
        double sizeCost = Length + Width + Height;
        double zoneCost = (ZoneDistance + 1) * Weight;

        return (decimal)sizeCost + (decimal)zoneCost;
    }

    // Precondition:  None
    // Postcondition: A string with the GroundPackage's data has been returned
    public override string ToString()
    {
        return String.Format("Origin Address:{8}{0}{8}{8}Destination Address:{8}{1}{8}{8}Length:{2}{8}Width:{3}{8}Height:{4}{8}Weight:{5}{8}Zone Distance:{6}{8}Cost:{7:C}{8}",
            OriginAddress, DestinationAddress, Length, Width, Height, Weight, ZoneDistance, CalcCost(), Environment.NewLine);
    }
}
