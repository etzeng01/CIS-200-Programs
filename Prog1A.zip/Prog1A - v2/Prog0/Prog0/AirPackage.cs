﻿// Program 1A
// CIS 200-01
// Due: 10/11/16
// Grading ID: C1814

// File: AirPackage.cs
// Abstract class derived from the Package class, holds same data as Package object

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class AirPackage : Package
{
    public int weightThreshold = 75;        // Threshold for package's weight to be considered heavy
    public int dimensionThreshold = 100;    // Threshold for package's dimensions to be considered large

    // Precondition: None
    // Postcondition: AirPackage created with values for origin address, destination address,
    //                length, width, height, and weight
    public AirPackage(Address originAddress, Address destAddress, double length, double width,
        double height, double weight) : base(originAddress, destAddress, length, width, height, weight)
    {
        // No new data to be initialized
    }

    // Precondition: Weight is a number
    // Postcondition: Set to true or false depending on whether the weight passes the threshold
    public bool IsHeavy()
    {
        if (Weight >= weightThreshold)
            return true;
        else
            return false;
    }

    // Precondition: Entered dimensions are numbers
    // Postcondition: Set to true or false depending on whether the dimensions pass the threshold
    public bool IsLarge()
    {
        if ((Length + Width + Height) >= dimensionThreshold)
            return true;
        else
            return false;
    }

    // Precondition:  None
    // Postcondition: A string with the AirPackage's data has been returned
    public override string ToString()
    {
        return String.Format("Origin Address:{8}{0}{8}{8}Destination Address:{8}{1}{8}{8}Length:{2}{8}Width:{3}{8}Height:{4}{8}Weight:{5}{8}Heavy Status:{6}{8}Large Status:{7}{8}",
            OriginAddress, DestinationAddress, Length, Width, Height, Weight, IsHeavy(), IsLarge(), Environment.NewLine);
    }
}
