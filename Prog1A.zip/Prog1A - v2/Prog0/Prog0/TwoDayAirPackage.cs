﻿// Program 1A
// CIS 200-01
// Due: 10/11/16
// Grading ID: C1814

// File: TWoDayAirPackage.cs
// This derives class TwoDayAirPackage from AirPackage and adds an enum for delivery type 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class TwoDayAirPackage : AirPackage
{
    public enum Delivery { EARLY, SAVER }; // Defines two choice enumeration for delivery type

    // Precondition: None
    // Postcondition: TwoDayAirPackage created with values for origin address, destination address,
    //                length, width, height, weight, and delivery type
    public TwoDayAirPackage(Address originAddress, Address destAddress, double length, double width,
        double height, double weight, Delivery deliveryType) : base(originAddress, destAddress, length,
            width, height, weight)
    {
        DeliveryType = deliveryType;
    }

    public Delivery DeliveryType
    {
        // Precondition: None
        // Postcondition: TwoDayAirPackage's delivery type returned
        get;

        // Precondition: None
        // Postcondition: TwoDayAirPackage's delivery type set to specified value
        set;
    }


    // Precondition:  None
    // Postcondition: The TwoDayAirPackage's cost has been returned
    public override decimal CalcCost()
    {
        const decimal DIMENSION_FACTOR = .25M;
        const decimal WEIGHT_FACTOR = .25M;
        const decimal SAVER_DISCOUNT = .9M;
        double dimensions = Length + Width + Height;
        decimal baseCost = ((decimal)dimensions * DIMENSION_FACTOR) + ((decimal)Weight * WEIGHT_FACTOR);

        if (DeliveryType == Delivery.SAVER)
            return baseCost * SAVER_DISCOUNT;
        else
            return baseCost;
    }

    // Precondition:  None
    // Postcondition: A string with the TwoDayAirPackage's data has been returned
    public override string ToString()
    {
        return String.Format("Origin Address:{7}{0}{7}{7}Destination Address:{7}{1}{7}{7}Length:{2}{7}Width:{3}{7}Height:{4}{7}Weight:{5}{7}Delivery Type:{6}{7}",
            OriginAddress, DestinationAddress, Length, Width, Height, Weight, DeliveryType, Environment.NewLine);
    }
}

