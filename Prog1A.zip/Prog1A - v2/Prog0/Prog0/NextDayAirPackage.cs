﻿// Program 1A
// CIS 200-01
// Due: 10/11/16
// Grading ID: C1814

// File: NextDayAirPackage.cs
// This file creates derived class NextDayAirPackage which implements an express fee for expedited shipping

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class NextDayAirPackage : AirPackage
{
    // Precondition: None
    // Postcondition: NextDayAirPackage created with values for origin address, destination address,
    //                length, width, height, weight, and express fee
    public NextDayAirPackage(Address originAddress, Address destAddress, double length, double width, 
        double height, double weight, decimal expressFee) : base(originAddress, destAddress, length, width, height, weight)
    {
        ExpressFee = expressFee;
    }

    public decimal ExpressFee
    {
        // Precondition: None
        // Postcondition: NextDayAirPackage's express fee has been returned
        get;
    }

    // Precondition:  None
    // Postcondition: The NextDayAirPackage's cost has been returned
    public override decimal CalcCost()
    {
        const decimal DIMENSION_FACTOR = .4M;
        const decimal WEIGHT_FACTOR = .3M;
        const decimal heavyCharge = .25M;
        const decimal largeCharge = .25M;
        decimal sizeCost = 0;
        decimal heavyCost = 0;
        double dimensions = Length + Width + Height;
        decimal baseCost = ((decimal)dimensions * DIMENSION_FACTOR) + ((decimal)Weight * WEIGHT_FACTOR) + ExpressFee;
        
        if (dimensions >= 100)
            sizeCost = baseCost += (largeCharge * baseCost);
     
        if(Weight >= 75)
            heavyCost = baseCost += (heavyCharge * baseCost);

        return baseCost + sizeCost + heavyCost;
    }

    // Precondition:  None
    // Postcondition: A string with the NextDayAirPackage's data has been returned
    public override string ToString()
    {
        return String.Format("Origin Address:{7}{0}{7}{7}Destination Address:{7}{1}{7}{7}Length:{2}{7}Width:{3}{7}Height:{4}{7}Weight:{5}{7}Express Fee:{6:C}{7}",
            OriginAddress, DestinationAddress, Length, Width, Height, Weight, ExpressFee, Environment.NewLine);
    }
}
