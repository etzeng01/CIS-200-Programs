﻿// Program 4
// CIS 200-01
// Due: 11/29/16
// Grading ID: C1814

// File: AscByType.cs
// EC: Creates comparer class for parcels, establishing order
// of ascending by parcel type then descending by price

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class AscByType : IComparer<Parcel>
{
    // Precondition: None
    // Postcondition: when parcel1 < parcel2, method returns negative #
    //                when parcel1 = parcel2, method returns 0
    //                when parcel1 > parcel2, method returns positive #
    public int Compare(Parcel parcel1, Parcel parcel2)
    {
        string type1; // type of parcel 1
        string type2; // type of parcel 2

        if (parcel1 == null & parcel2 == null) // Both null
            return 0;                          // Equal

        if (parcel1 == null) // only parcel1 null
            return -1;

        if (parcel2 == null) // only parcel2 null
            return 1;

        type1 = parcel1.GetType().ToString();
        type2 = parcel2.GetType().ToString();

        // if the types are the same
        if (type1 == type2)
            return (parcel1.CalcCost()).CompareTo(parcel2.CalcCost());

        // if the types are different, displays in descending order
        return (-1)*(type1.CompareTo(type2));
    }
}
