﻿// Program 4
// CIS 200-01
// Due: 11/29/16
// Grading ID: C1814

// File: DescByDestZip.cs
// Creates comparer class for parcels, establishing descending
// order by destination zip code 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class DescByDestZip : IComparer<Parcel>
{
    // Precondition: None
    // Postcondition: when parcel1 < parcel2, method returns negative #
    //                when parcel1 = parcel2, method returns 0
    //                when parcel1 > parcel2, method returns positive #
    public int Compare(Parcel parcel1, Parcel parcel2)
    {
        if (parcel1 == null & parcel2 == null) // Both null
            return 0;

        if (parcel1 == null) // only parcel1 null
            return -1;

        if (parcel2 == null) // only parcel2 null
            return 1;

        return (parcel2.DestinationAddress.Zip).CompareTo(parcel1.DestinationAddress.Zip);
    }
}
