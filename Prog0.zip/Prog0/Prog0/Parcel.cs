﻿// Grading ID: C1814
// Due: 9/22/16
// Program 0
// CIS 200-01
// Abstract parcel class that sets up base for all future deliverables with 
// an origin and destination address

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class Parcel
    {
        private Address _origin;        // Parcel's origin address
        private Address _destination;   // Parcel's desitnation address

        // Precondition: None
        // Postcondtiion: Parcel initialized with an origin and destination address
        public Parcel(Address origin, Address destination)
        {
            OriginAddress = origin;
            DestinationAddress = destination;
        }

        public Address OriginAddress
        {
            // Precondition: None
            // Postcondition: Origin address returned
            get
            {
                return _origin;
            }

            // Precondition: None
            // Postcondition: Origin set to specified value
            set
            {
                _origin = value;
            }
        }

        public Address DestinationAddress
        {
            // Precondition: None
            // Postcondition: Destination address returned
            get
            {
                return _destination;
            }

            // Precondition: None
            // Postcondition: Destination set to specified value
            set
            {
                _destination = value;
            }
        }

        // Precondition: None
        // Postcondition: Returns cost formatted as decimal
        public abstract decimal CalcCost();     // Abstract method to be overridden by derived classes

        // Precondition: None
        // Postcondition: Displays origin address, destination address, and cost
        //                formatted in the desired manner
        public override string ToString()
        {
            return string.Format("Origin:{2}{0}{2}Destination:{2}{1}{2}Cost:{2}",
                OriginAddress, DestinationAddress, System.Environment.NewLine);
        }
    }
}