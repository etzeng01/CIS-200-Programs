﻿// Grading ID: C1814
// Due: 9/22/16
// Program 0
// CIS 200-01
// Class used to create all components of an address, the name, address line 1, address line 2,
// city, state, and zip. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class Address
    {
        public const int MIN_ZIP = 00000;        // Min zip 
        public const int MAX_ZIP = 99999;        // Max zip

        private string _name;       // Sender/recipient name
        private string _address1;   // Sender/recipient address line 1
        private string _address2;   // Sender/recipient address line 2
        private string _city;       // Sender/recipient city
        private string _state;      // Sender/recipient state
        private int _zip;    // Sender/recipient zip code

        // Precondition: None
        // Postcondtiion: Address initialized with values for name,
        //                address line 1, address line 2, city, state,
        //                and zip code
        public Address(string name, string address1, string address2,
            string city, string state, int zipCode)
        {
            // Establish default zip in case entered zip is invalid
            Zip = MIN_ZIP;

            Name = name;
            Address1 = address1;
            Address2 = address2;
            City = city;
            State = state;
            Zip = zipCode;
        }

        public string Name
        {
            // Precondition: None
            // Postcondition: Name is returned
            get
            {
                return _name;
            }

            // Precondition: None
            // Postcondition: Name has been set to specified value
            set
            {
                _name = value;
            }
        }

        public string Address1
        {
            // Precondition: None
            // Postcondition: Address1 is returned
            get
            {
                return _address1;
            }

            // Precondition: None
            // Postcondition: Address1 has been set to specified value
            set
            {
                _address1 = value;
            }
        }

        public string Address2
        {
            // Precondition: None
            // Postcondition: Address2 is returned
            get
            {
                return _address2;
            }

            // Precondition: None
            // Postcondition: Address2 has been set to specified value
            set
            {
                _address2 = value;
            }
        }

        public string City
        {
            // Precondition: None
            // Postcondition: City is returned
            get
            {
                return _city;
            }

            // Precondition: None
            // Postcondition: City has been set to specified value
            set
            {
                _city = value;
            }
        }

        public string State
        {
            // Precondition: None
            // Postcondition: State is returned
            get
            {
                return _state;
            }

            // Precondition: None
            // Postcondition: State has been set to specified value
            set
            {
                _state = value;
            }
        }

        public int Zip
        {
            // Precondition: none
            // Postcondition: Zip code is returned
            get
            {
                return _zip;
            }

            // Precondition: none ADD VALIATION if else
            // Postcondition: Zip code has been set to specified value
            set
            {
                if (_zip >= 00000)
                {
                    _zip = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Zip", value, "Zip out of range");
                }
            }
        }

        // Precondition: None
        // Postcondition: String returned presenting all fields in four lines
        public override string ToString()
        {
            return String.Format("{0}{6}{1}{6}{2}{6}{3}, {4} {5:D5}",
                Name, Address1, Address2, City, State, Zip,
                System.Environment.NewLine);
        }

    }
}
