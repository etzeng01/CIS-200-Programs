﻿// Grading ID: C1814
// Due: 9/22/16
// Program 0
// CIS 200-01
// Class used to display information needed when shipping a letter, including origin 
// address, destination address, and the shipping cost

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class Letter : Parcel
    {
        private decimal _shipCost; // Variable that holds the fixed cost of shipping

        // Precondition: None
        // POstcondition: Letter has been initialized with origin address, destination
        //                address, and the shipping cost
        public Letter(Address origin, Address destination, decimal shipCost) : base(origin, destination)
        {
            Cost = shipCost;
        }

        private decimal Cost
        {
            // Precondition: None
            // Postcondition: Shipping cost is returned
            get
            {
                return _shipCost;
            }

            // Precondition: None
            // Postcondition: Ship cost has been set to specified value
            set
            {
                if (value >= 0)
                {
                    _shipCost = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Ship Cost", value, "Shipping cost out of range.");
                }
            }
        }

        // Precondition: Valid cost input
        // Postocndition: Puts input through CalcCost method, returns Cost
        public override decimal CalcCost()
        {
            return Cost;
        }

        // Precondition: None
        // Postcondition: String returned representing the cost
        public override string ToString()
        {
            return String.Format("Origin:{3}{0}{3}{3}Destination:{3}{1}{3}{3}Cost: {2:C}{3}",
                OriginAddress, DestinationAddress, Cost, System.Environment.NewLine);
        }
    }
}
