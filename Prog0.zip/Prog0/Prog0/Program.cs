﻿// Grading ID: C1814
// Due: 9/22/16
// Program 0
// CIS 200-01

// Creates a simple console application used to create a list of
// letters with corresponding addresses and list them; ensures 
// classes are used correctly

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Program
    {
        // Precondition: None
        // Postcondition: The Parcel class has been tested
        static void Main(string[] args)
        {
            Address address1 = new Address("Draco Malfoy", "The Room Nobody is Allowed In Because He's Sulking", "1352 Malfoy Drive",                       // Test address 1
                "Binghamton", "NYC", 00000);
            Address address2 = new Address("Harry Potter", "4 Privet Drive", "Little Winging", "Surry",                   // Test address 2
                "England", 30191);
            Address address3 = new Address("Harry Pooter", "4 Under the Stairs Cupboard", "Middle of Nowhere", "There's No Such Thing As Magic",      // Test address 3
                "Dursley-Central", 30191);
            Address address4 = new Address("Hermione Granger", "3918 Prim and Proper Drive", "Gryffindor's Princess", "Oxford",                       // Test address 4
                "England", 20193);

            Letter letter1 = new Letter(address1, address2, 3.10m);     // Test letter 1
            Letter letter2 = new Letter(address2, address3, 9.1m);      // Test letter 2
            Letter letter3 = new Letter(address3, address4, 1.3m);      // Test letter 3

            List<Letter> theLetters = new List<Letter>() { letter1, letter2, letter3 };  // Create list of letters called theLetters

            Console.WriteLine("Letters");
            Console.WriteLine();

            // Precondition: None
            // Postconditon: Writes the contents of theLetters list to the console
            foreach (Letter l in theLetters)
            {
                Console.WriteLine(l);
                Console.WriteLine("-------");
                Console.WriteLine();
            } 

        }
    }
}

