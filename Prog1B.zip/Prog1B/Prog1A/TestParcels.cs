﻿// Program 1B
// CIS 200-01
// Due: 10/17/2016
// Grading ID: 1814

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("John Smith", "123 Any St.", "Apt. 45",
                "Louisville", "KY", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.", "",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Draco Malfoy", "492 Malfoy Manor", "Suite 4A",
                "Salisbury", "Wiltshire", 32941); // Test Address 5
            Address a6 = new Address("Harry Potter", "4 Privet Drive", "Cupboard Under the Stairs",
                "Little Whinging", "Surrey", 39104); // Test Address 6
            Address a7 = new Address("Hermione Granger", "3025 Magnolia Dr.", "Apt. 3",
                "New York", "New York", 30183); // Test address 7
            Address a8 = new Address("Blair Waldorf", "3918 Manhattan Ave.", "Apt. 9",
                "New York", "New York", 30183);

            // Letter test objects
            Letter letter1 = new Letter(a1, a2, 3.95M);
            Letter letter2 = new Letter(a5, a7, 93.2M);
            Letter letter3 = new Letter(a1, a5, 95.21M);
            Letter letter4 = new Letter(a2, a8, 20.1m);

            // Ground test objects
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);
            GroundPackage gp2 = new GroundPackage(a6, a8, 35, 34, 13, 59);
            GroundPackage gp3 = new GroundPackage(a2, a5, 23, 5, 1, 2);
            GroundPackage gp4 = new GroundPackage(a1, a7, 3, 8, 12, 4);

            // Next Day test objects
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a8, a7, 392.1, 381.3, 1933,
                93, 8.0M);
            NextDayAirPackage ndap3 = new NextDayAirPackage(a3, a7, 39, 91, 23,
                30, 7.92M);
            NextDayAirPackage ndap4 = new NextDayAirPackage(a7, a8, 30, 20, 3,
                39, 20.3M);

            // Two Day test objects
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, 
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a5, a8, 32, 53, 23,
                23, TwoDayAirPackage.Delivery.Early);
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a2, a8, 32, 53, 1,
                30, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap4 = new TwoDayAirPackage(a4, a6, 31, 6, 3,
                95, TwoDayAirPackage.Delivery. Early);

            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populate list
            parcels.Add(letter2);
            parcels.Add(letter3);
            parcels.Add(letter4);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(gp3);
            parcels.Add(gp4);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(ndap4);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);
            parcels.Add(tdap4);

            Console.WriteLine("Original List:");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine("====================");
            }
            Pause();

            // LINQ query to select all parcels and order by destination zip (descending)
            var destinationZipSort =
                from p in parcels
                orderby p.DestinationAddress.Zip descending
                select p;

            // Display results of LINQ query
            Console.WriteLine("\nParcels ordered by zip code in descending order:");
            foreach (var p in destinationZipSort)
                Console.WriteLine("{0}", p, "{0}");

            Pause();

            // LINQ query to select all parcels and order by cost (ascending)
            var costSort =
               from p in parcels
               orderby p.CalcCost() ascending
               select p;

            // Display results of LINQ query
            Console.WriteLine("\nParcels ordered by cost in ascending order:");
            foreach(var p in costSort)
                Console.WriteLine("{0}", p, "{0}");

            Pause();

            // LINQ query to select parcels by parcel type (ascending) then cost (descending)
            var typeSort =
                from p in parcels
                orderby p.GetType().ToString() ascending, p.CalcCost() descending
                select p;

            // Display results of LINQ query
            Console.WriteLine("\nParcels ordered by type in ascending order then cost in descending order:");
            foreach (var p in typeSort)
                Console.WriteLine("{0}", p, "{0}");

            Pause();

            // LINQ query to select all AirPackage objects that are heavy and order, in descending order, by weight
            var heavyAirPackageSort =
                from p in parcels
                where p == p as AirPackage
                let package = (AirPackage) p
                where package.IsHeavy() == true
                orderby package.Weight descending
                select p;

            //  Display results of LINQ query
            Console.WriteLine("\nAll AirPackage parcels considered to be heavy, ordered by weight");
            foreach (var p in heavyAirPackageSort)
                Console.WriteLine("{0}", p, "{0}");

            Pause();

        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
