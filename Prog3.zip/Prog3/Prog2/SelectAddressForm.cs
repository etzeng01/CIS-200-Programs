﻿// Program 2
// CIS 200
// Fall 2016
// Due: 11/15/2016
// By: C1814

// File: SelectAddressForm.cs
// This class creates the SelectAddress dialog form that allows a user to select an
// address to edit. Performs validation using validating and validated events in conjunction
// with an ErrorProvider.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class SelectAddressForm : Form
    {
        private List<Address> addresses; // List of addresses

        // Precondition: List addresses populated with available
        //               addresses
        // Postcondition: Form's GUI prepared for display
        public SelectAddressForm(List<Address> addressesList)
        {
            InitializeComponent();
            addresses = addressesList; 
        }

        // Precondition: None
        // Postcondition: List of addresses used to populate 
        //                address ComboBox
        private void SelectAddress_Load(object sender, EventArgs e)
        {
            foreach (Address address in addresses)
                selectAddressComboBx.Items.Add(address.Name);
        }
        
        public int AddressIndex
        {
            // Precondition: None
            // Postcondition: Index of selected address in ComboBox returned
            get
            {
                return selectAddressComboBx.SelectedIndex;
            }
        }
        // Precondition: Focus shifting from selectAddressComboBx
        // Postcondition: If selection invalid, focus stays and ErrorProvider
        //                highlights field
        private void selectAddressComboBx_Validating(object sender, CancelEventArgs e)
        {
            if (selectAddressComboBx.SelectedIndex == -1)   // No address selected
            {
                e.Cancel = true;
                selectAddressErrorProvider.SetError(selectAddressComboBx, "Must select address!");
            }
        }

        // Precondition: Validating of selectAddressComboBx not cancelled, data is okay
        // Postcondition: ErrorProvider cleared, focus allowed to change
        private void selectAddressComboBx_Validated(object sender, EventArgs e)
        {
            selectAddressErrorProvider.SetError(selectAddressComboBx, "");
        }

        // Precondtiion: User pressed on cancel button
        // Postcondition: Form closes, sends cancel
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;    // Form closes, returns cancel result
        }

        private void selectBtn_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                this.DialogResult = DialogResult.OK; // Form closes and returns an OK result
            }
        }
    }
}
