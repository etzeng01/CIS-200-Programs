﻿// Program 2
// CIS 200
// Fall 2016
// Due: 11/1/2016
// By: Andrew L. Wright (Students use Grading ID) and C1814

// File: Prog2Form.cs
// This class creates the main GUI for Program 2. It provides a
// File menu with About and Exit items, an Insert menu with Address and
// Letter items, and a Report menu with List Addresses and List Parcels
// items.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;


namespace UPVApp
{
    [Serializable]

    public partial class Prog3Form : Form
    {
        private UserParcelView upv; // The UserParcelView

        // Precondition:  None
        // Postcondition: The form's GUI is prepared for display. A few test addresses are
        //                added to the list of addresses
        public Prog3Form()
        {
            InitializeComponent();

            upv = new UserParcelView();

        }

        // Precondition:  File, About menu item activated
        // Postcondition: Information about author displayed in dialog box
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine; // Newline shorthand

            MessageBox.Show($"Program 3{NL}By: C1814{NL}CIS 200{NL}Fall 2016",
                "About Program 3");
        }

        // Precondition:  File, Exit menu item activated
        // Postcondition: The application is exited
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Precondition:  Insert, Address menu item activated
        // Postcondition: The Address dialog box is displayed. If data entered
        //                are OK, an Address is created and added to the list
        //                of addresses
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm();    // The address dialog box form
            DialogResult result = addressForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try
                {
                    upv.AddAddress(addressForm.AddressName, addressForm.Address1,
                        addressForm.Address2, addressForm.City, addressForm.State,
                        int.Parse(addressForm.ZipText)); // Use form's properties to create address
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Address Validation!", "Validation Error");
                }
            }

            addressForm.Dispose(); // Best practice for dialog boxes
        }

        // Precondition:  Report, List Addresses menu item activated
        // Postcondition: The list of addresses is displayed in the addressResultsTxt
        //                text box
        private void listAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            string NL = Environment.NewLine;            // Newline shorthand

            result.Append("Addresses:");
            result.Append(NL); // Remember, \n doesn't always work in GUIs
            result.Append(NL);

            foreach (Address a in upv.AddressList)
            {
                result.Append(a.ToString());
                result.Append(NL);
                result.Append("------------------------------");
                result.Append(NL);
            }

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.Focus();
            reportTxt.SelectionStart = 0;
            reportTxt.SelectionLength = 0;
        }

        // Precondition:  Insert, Letter menu item activated
        // Postcondition: The Letter dialog box is displayed. If data entered
        //                are OK, a Letter is created and added to the list
        //                of parcels
        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letterForm; // The letter dialog box form
            DialogResult result;   // The result of showing form as dialog

            if (upv.AddressCount < LetterForm.MIN_ADDRESSES) // Make sure we have enough addresses
            {
                MessageBox.Show("Need " + LetterForm.MIN_ADDRESSES + " addresses to create letter!",
                    "Addresses Error");
                return;
            }

            letterForm = new LetterForm(upv.AddressList); // Send list of addresses
            result = letterForm.ShowDialog();

            if (result == DialogResult.OK) // Only add if OK
            {
                try
                {
                    // For this to work, LetterForm's combo boxes need to be in same
                    // order as upv's AddressList
                    upv.AddLetter(upv.AddressAt(letterForm.OriginAddressIndex),
                        upv.AddressAt(letterForm.DestinationAddressIndex),
                        decimal.Parse(letterForm.FixedCostText)); // Letter to be inserted
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Letter Validation!", "Validation Error");
                }
            }

            letterForm.Dispose(); // Best practice for dialog boxes
        }

        // Precondition:  Report, List Parcels menu item activated
        // Postcondition: The list of parcels is displayed in the parcelResultsTxt
        //                text box
        private void listParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            decimal totalCost = 0;                      // Running total of parcel shipping costs
            string NL = Environment.NewLine;            // Newline shorthand

            result.Append("Parcels:");
            result.Append(NL); // Remember, \n doesn't always work in GUIs
            result.Append(NL);

            foreach (Parcel p in upv.ParcelList)
            {
                result.Append(p.ToString());
                result.Append(NL);
                result.Append("------------------------------");
                result.Append(NL);
                totalCost += p.CalcCost();
            }

            result.Append(NL);
            result.Append($"Total Cost: {totalCost:C}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.Focus();
            reportTxt.SelectionStart = 0;
            reportTxt.SelectionLength = 0;
        }

        // Precondition: File, Open menu item activated
        // Postcondition: File containing UPV object's data opened, replacing
        //                addresses and parcels currently in the application
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BinaryFormatter data = new BinaryFormatter();   // Object for deserializing UPv data
            FileStream input;                               // Stream for reading from a file
            DialogResult result;                            // Result of file dialog box
            string fileName;                                // File to save data to

            // Create Open dialog box
            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;
            }

            // If the user clicks okay
            if (result == DialogResult.OK)
            {
                if (fileName == string.Empty)   // If the file name is empty, show an error
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // create Filestream to access contents of file, assign to temporary UPV object
                    try
                    {
                        input = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                        upv = (UserParcelView)data.Deserialize(input);
                    }

                    // Exception if there is a problem opening the file
                    catch (IOException)
                    {
                        MessageBox.Show("Error reading from file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Precondition: File, Save As  menu item activated
        // Postcondition: UPV saved to file 
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BinaryFormatter saving = new BinaryFormatter();     // Object to serialize UPV
            FileStream output;                                  // Stream for writing to file
            DialogResult result;                                // Result of File dialog box
            string fileName;                                    // Name of file where data will be saved

            using (SaveFileDialog chooseFile = new SaveFileDialog()) // Create Save File dialog
            {
                chooseFile.CheckFileExists = false;     // Let user create file
                result = chooseFile.ShowDialog();
                fileName = chooseFile.FileName;
            }

            // If user clicks on OK
            if (result == DialogResult.OK)
            {
                if (fileName == string.Empty)   // check if string is empty, produce error if so
                {
                    MessageBox.Show("Invalid file name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // Save file using FileStream if specified file is valid
                    try
                    {
                        output = new FileStream(fileName, FileMode.Create, FileAccess.Write);   // Open file ewtih write access
                        saving.Serialize(output, upv);                                          // Serialize UPV 
                        output.Close();                                                         // Close stream
                    }

                    // Catch error if file cannot be found
                    catch (IOException)
                    {
                        MessageBox.Show("Error writing to file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                } 
            }
        }

        // Precondition: Edit, Address menu item clicked
        // Postcondition: Address selected has been edited with user's
        //                new data, replaces existing address' properties
        private void editToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            List<Address> addressList;

            addressList = upv.addresses;

            if (addressList.Count() == 0)   // If there are no addresses
            {
                MessageBox.Show("Must have addresses to edit", "Edit Error");
            }
            else
            {
                SelectAddressForm saForm = new SelectAddressForm(addressList); // Create select address form
                DialogResult result = saForm.ShowDialog();

                if (result == DialogResult.OK)  // Edit if OK
                {
                    int addressIndex;
                    addressIndex = saForm.AddressIndex;

                    if (addressIndex >= 0) // There is an item selected
                    {
                        Address editAddress = addressList[addressIndex];    // Address to edit
                        AddressForm addressForm = new AddressForm();        // Address dialog box form
                        
                        // Populate form fields with selected info
                        addressForm.AddressName = editAddress.Name;
                        addressForm.Address1 = editAddress.Address1;
                        addressForm.Address2 = editAddress.Address2;
                        addressForm.City = editAddress.City;
                        addressForm.State = editAddress.State;
                        addressForm.ZipText = editAddress.Zip.ToString();

                        DialogResult editResult = addressForm.ShowDialog();

                        if (editResult == DialogResult.OK)    // Update only if address has passed validation
                        {
                            // Edit address properties using form fields
                            editAddress.Name = addressForm.AddressName;
                            editAddress.Address1 = addressForm.Address1;
                            editAddress.Address2 = addressForm.Address2;
                            editAddress.City = addressForm.City;
                            editAddress.State = addressForm.State;
                            editAddress.Zip = int.Parse(addressForm.ZipText);
                        }
                    }
                }
            }
        }
    }
}