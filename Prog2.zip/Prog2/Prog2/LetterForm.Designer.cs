﻿namespace UPVApp
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.originLbl = new System.Windows.Forms.Label();
            this.destinationLbl = new System.Windows.Forms.Label();
            this.fixedCostLbl = new System.Windows.Forms.Label();
            this.originComboBx = new System.Windows.Forms.ComboBox();
            this.destinationComboBx = new System.Windows.Forms.ComboBox();
            this.fixedCostTxtBx = new System.Windows.Forms.TextBox();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.originErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.destinationErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.fixedCostErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.originErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.destinationErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedCostErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // originLbl
            // 
            this.originLbl.AutoSize = true;
            this.originLbl.Location = new System.Drawing.Point(75, 28);
            this.originLbl.Name = "originLbl";
            this.originLbl.Size = new System.Drawing.Size(70, 25);
            this.originLbl.TabIndex = 0;
            this.originLbl.Text = "Origin:";
            // 
            // destinationLbl
            // 
            this.destinationLbl.AutoSize = true;
            this.destinationLbl.Location = new System.Drawing.Point(30, 84);
            this.destinationLbl.Name = "destinationLbl";
            this.destinationLbl.Size = new System.Drawing.Size(115, 25);
            this.destinationLbl.TabIndex = 1;
            this.destinationLbl.Text = "Destination:";
            // 
            // fixedCostLbl
            // 
            this.fixedCostLbl.AutoSize = true;
            this.fixedCostLbl.Location = new System.Drawing.Point(33, 140);
            this.fixedCostLbl.Name = "fixedCostLbl";
            this.fixedCostLbl.Size = new System.Drawing.Size(112, 25);
            this.fixedCostLbl.TabIndex = 2;
            this.fixedCostLbl.Text = "Fixed Cost:";
            // 
            // originComboBx
            // 
            this.originComboBx.FormattingEnabled = true;
            this.originComboBx.Location = new System.Drawing.Point(160, 25);
            this.originComboBx.Name = "originComboBx";
            this.originComboBx.Size = new System.Drawing.Size(237, 32);
            this.originComboBx.TabIndex = 3;
            this.originComboBx.Validating += new System.ComponentModel.CancelEventHandler(this.originComboBx_Validating);
            this.originComboBx.Validated += new System.EventHandler(this.originComboBx_Validated);
            // 
            // destinationComboBx
            // 
            this.destinationComboBx.FormattingEnabled = true;
            this.destinationComboBx.Location = new System.Drawing.Point(160, 81);
            this.destinationComboBx.Name = "destinationComboBx";
            this.destinationComboBx.Size = new System.Drawing.Size(237, 32);
            this.destinationComboBx.TabIndex = 4;
            this.destinationComboBx.Validating += new System.ComponentModel.CancelEventHandler(this.destinationComboBx_Validating);
            this.destinationComboBx.Validated += new System.EventHandler(this.destinationComboBx_Validated);
            // 
            // fixedCostTxtBx
            // 
            this.fixedCostTxtBx.Location = new System.Drawing.Point(160, 137);
            this.fixedCostTxtBx.Name = "fixedCostTxtBx";
            this.fixedCostTxtBx.Size = new System.Drawing.Size(237, 29);
            this.fixedCostTxtBx.TabIndex = 5;
            this.fixedCostTxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.fixedCostTxtBx_Validating);
            this.fixedCostTxtBx.Validated += new System.EventHandler(this.fixedCostTxtBx_Validated);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(38, 203);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(169, 78);
            this.okBtn.TabIndex = 6;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(237, 203);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(160, 78);
            this.cancelBtn.TabIndex = 7;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // originErrorProvider
            // 
            this.originErrorProvider.ContainerControl = this;
            // 
            // destinationErrorProvider
            // 
            this.destinationErrorProvider.ContainerControl = this;
            // 
            // fixedCostErrorProvider
            // 
            this.fixedCostErrorProvider.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 319);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.fixedCostTxtBx);
            this.Controls.Add(this.destinationComboBx);
            this.Controls.Add(this.originComboBx);
            this.Controls.Add(this.fixedCostLbl);
            this.Controls.Add(this.destinationLbl);
            this.Controls.Add(this.originLbl);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            this.Load += new System.EventHandler(this.LetterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.originErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.destinationErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fixedCostErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originLbl;
        private System.Windows.Forms.Label destinationLbl;
        private System.Windows.Forms.Label fixedCostLbl;
        private System.Windows.Forms.ComboBox originComboBx;
        private System.Windows.Forms.ComboBox destinationComboBx;
        private System.Windows.Forms.TextBox fixedCostTxtBx;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ErrorProvider originErrorProvider;
        private System.Windows.Forms.ErrorProvider destinationErrorProvider;
        private System.Windows.Forms.ErrorProvider fixedCostErrorProvider;
    }
}