﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class LetterForm : Form
    {
        // private List<Letter> letters;       // List of letters
        private List<Address> addresses;    // List of addresses

        // Precondition: Lists letterList and addressList are populated with available
        //               Letters and Addresses, respectively, to choose from
        // Postcondition: Form's GUI prepared for display
        public LetterForm(List<Address> addressList)
        {
            InitializeComponent();

            // letters = letterList;
            addresses = addressList;
        }
        
        // Precondition: None
        // Postcondtiion: Lists of addresses used to populate the origin
        //                and destination combo boxes
        private void LetterForm_Load(object sender, EventArgs e)
        {
            foreach (Address item in addresses)
            {
                originComboBx.Items.Add(item.Name);
            }

            foreach (Address item in addresses)
            {
                destinationComboBx.Items.Add(item.Name);
            }
        }

        internal int OriginIndex
        {
            // Precondition: None
            // Postcondition: The index of form's selected origin combo box returned
            get
            {
                return originComboBx.SelectedIndex;
            }
        }

        internal int DestinationIndex
        {
            // Precondition: None
            // Postcondition: The index of form's selected destination combo box returned
            get
            {
                return destinationComboBx.SelectedIndex;
            }
        }

        internal string FixedCost
        {
            // Precondition: None
            // Postcondition: Text of form's Name field returned
            get
            {
                return fixedCostTxtBx.Text;
            }

            // Precondtion: None
            // Postcondition: Text of form's Name field set to specifed value
            set
            {
                fixedCostTxtBx.Text = value;
            }
        }

        // Precondition: Focus shifting from originComboBox
        // Postcondition: If selection is invalid, focus remains and error provider
        //                highlights the field
        private void originComboBx_Validating(object sender, CancelEventArgs e)
        {
            if (originComboBx.SelectedIndex == -1) // Nothing selected
            {
                e.Cancel = true;
                originErrorProvider.SetError(originComboBx, "Must select Origin");
            }
        }

        // Precondition: Validating of originComboBx not cancelled, data OK
        // Postcondition: Error provider cleared and focus allowed to change
        private void originComboBx_Validated(object sender, EventArgs e)
        {
            originErrorProvider.SetError(originComboBx, "");
        }

        // Precondition: Focus shifting from destinationComboBox
        // Postcondition: If selection is invalid, focus remains and error provider
        //                highlights the field
        private void destinationComboBx_Validating(object sender, CancelEventArgs e)
        {
            if(destinationComboBx.SelectedIndex == -1) // Nothing selected
            {
                e.Cancel = true;
                destinationErrorProvider.SetError(destinationComboBx, "Must select Destination");
            }
            else if(destinationComboBx.SelectedIndex == originComboBx.SelectedIndex)
            {
                e.Cancel = true;
                destinationErrorProvider.SetError(destinationComboBx, "Destination address may not be the same as Origin address");
            }
        }

        // Precondition: Validating of destinationComboBx not cancelled, data OK
        // Postcondition: Error provider cleared and focus allowed to change
        private void destinationComboBx_Validated(object sender, EventArgs e)
        {
            destinationErrorProvider.SetError(destinationComboBx, "");
        }

        // Precondition:  Focus is shifting from fixedCostTxtBx
        // Postcondition: If selection invalid, focus remains and error provider
        //                highlights the field
        private void fixedCostTxtBx_Validating(object sender, CancelEventArgs e)
        {
            if (fixedCostTxtBx.TextLength == -1) // If field is empty
            {
                e.Cancel = true;
                fixedCostErrorProvider.SetError(fixedCostTxtBx, "Must provide Fixed Cost");
            }
            else
            {
                decimal fixedCost;      // Variable to hold fixed cost
                const int MIN_COST = 0; // Minimum cost
                decimal.TryParse(fixedCostTxtBx.Text, out fixedCost); // Parse fixedCostTxtBx's text

                if (fixedCost >= MIN_COST)
                {
                    fixedCostErrorProvider.SetError(fixedCostTxtBx, "");
                }
                else
                {
                    fixedCostErrorProvider.SetError(fixedCostTxtBx, "Fixed cost must be non-negative");
                }
            }
        }

        // Precondition: Validating of zipComboBx not cancelled, data is okay
        // Postcondition: Error provider cleared, focus allowed to change
        private void fixedCostTxtBx_Validated(object sender, EventArgs e)
        {
            fixedCostErrorProvider.SetError(fixedCostTxtBx, "");
        }

        // Precondition: User clicked on okBtn
        // Postcondition: If there is an invalid field on the dialog box,
        //                keeps form open and gives first invalid field the focus.
        //                Otherwise, returns okay and closes the form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            if (ValidateChildren()) // If all controls validate
                this.DialogResult = DialogResult.OK;
        }

        // Precondition: User pressed cancelBtn
        // Postcondition: Form closes and sends Cancel
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // left-click
                this.DialogResult = DialogResult.Cancel; // exit form
        }
    }
}
