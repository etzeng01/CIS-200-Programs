﻿namespace UPVApp
{
    partial class Prog2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.prog2MenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addressInsertMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.letterInsertMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listAddressesReportMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listParcelsReportMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportTxtBx = new System.Windows.Forms.TextBox();
            this.prog2MenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // prog2MenuStrip
            // 
            this.prog2MenuStrip.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.prog2MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenuItem,
            this.insertMenuItem,
            this.reportMenuItem});
            this.prog2MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.prog2MenuStrip.Name = "prog2MenuStrip";
            this.prog2MenuStrip.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.prog2MenuStrip.Size = new System.Drawing.Size(357, 24);
            this.prog2MenuStrip.TabIndex = 0;
            this.prog2MenuStrip.Text = "menuStrip1";
            // 
            // fileMenuItem
            // 
            this.fileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutFileMenuItem,
            this.exitFileMenuItem});
            this.fileMenuItem.Name = "fileMenuItem";
            this.fileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.fileMenuItem.Size = new System.Drawing.Size(35, 22);
            this.fileMenuItem.Text = "&File";
            // 
            // aboutFileMenuItem
            // 
            this.aboutFileMenuItem.Name = "aboutFileMenuItem";
            this.aboutFileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.aboutFileMenuItem.Size = new System.Drawing.Size(142, 22);
            this.aboutFileMenuItem.Text = "&About";
            this.aboutFileMenuItem.Click += new System.EventHandler(this.aboutFileMenuItem_Click);
            // 
            // exitFileMenuItem
            // 
            this.exitFileMenuItem.Name = "exitFileMenuItem";
            this.exitFileMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.exitFileMenuItem.Size = new System.Drawing.Size(142, 22);
            this.exitFileMenuItem.Text = "E&xit";
            this.exitFileMenuItem.Click += new System.EventHandler(this.exitFileMenuItem_Click);
            // 
            // insertMenuItem
            // 
            this.insertMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addressInsertMenuItem,
            this.letterInsertMenuItem});
            this.insertMenuItem.Name = "insertMenuItem";
            this.insertMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.insertMenuItem.Size = new System.Drawing.Size(48, 22);
            this.insertMenuItem.Text = "&Insert";
            // 
            // addressInsertMenuItem
            // 
            this.addressInsertMenuItem.Name = "addressInsertMenuItem";
            this.addressInsertMenuItem.Size = new System.Drawing.Size(113, 22);
            this.addressInsertMenuItem.Text = "Address";
            this.addressInsertMenuItem.Click += new System.EventHandler(this.addressInsertMenuItem_Click);
            // 
            // letterInsertMenuItem
            // 
            this.letterInsertMenuItem.Name = "letterInsertMenuItem";
            this.letterInsertMenuItem.Size = new System.Drawing.Size(113, 22);
            this.letterInsertMenuItem.Text = "Letter";
            this.letterInsertMenuItem.Click += new System.EventHandler(this.letterInsertMenuItem_Click);
            // 
            // reportMenuItem
            // 
            this.reportMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listAddressesReportMenuItem,
            this.listParcelsReportMenuItem});
            this.reportMenuItem.Name = "reportMenuItem";
            this.reportMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.R)));
            this.reportMenuItem.Size = new System.Drawing.Size(52, 22);
            this.reportMenuItem.Text = "&Report";
            // 
            // listAddressesReportMenuItem
            // 
            this.listAddressesReportMenuItem.Name = "listAddressesReportMenuItem";
            this.listAddressesReportMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.listAddressesReportMenuItem.Size = new System.Drawing.Size(182, 22);
            this.listAddressesReportMenuItem.Text = "List &Addresses";
            this.listAddressesReportMenuItem.Click += new System.EventHandler(this.listAddressesReportMenuItem_Click);
            // 
            // listParcelsReportMenuItem
            // 
            this.listParcelsReportMenuItem.Name = "listParcelsReportMenuItem";
            this.listParcelsReportMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.listParcelsReportMenuItem.Size = new System.Drawing.Size(182, 22);
            this.listParcelsReportMenuItem.Text = "List &Parcels";
            this.listParcelsReportMenuItem.Click += new System.EventHandler(this.listParcelsReportMenuItem_Click);
            // 
            // reportTxtBx
            // 
            this.reportTxtBx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.reportTxtBx.Location = new System.Drawing.Point(11, 26);
            this.reportTxtBx.Margin = new System.Windows.Forms.Padding(2);
            this.reportTxtBx.Multiline = true;
            this.reportTxtBx.Name = "reportTxtBx";
            this.reportTxtBx.ReadOnly = true;
            this.reportTxtBx.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.reportTxtBx.Size = new System.Drawing.Size(335, 333);
            this.reportTxtBx.TabIndex = 1;
            // 
            // Prog2Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(357, 370);
            this.Controls.Add(this.reportTxtBx);
            this.Controls.Add(this.prog2MenuStrip);
            this.MainMenuStrip = this.prog2MenuStrip;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Prog2Form";
            this.Text = "Program 2";
            this.prog2MenuStrip.ResumeLayout(false);
            this.prog2MenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip prog2MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutFileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitFileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addressInsertMenuItem;
        private System.Windows.Forms.ToolStripMenuItem letterInsertMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listAddressesReportMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listParcelsReportMenuItem;
        private System.Windows.Forms.TextBox reportTxtBx;
    }
}

