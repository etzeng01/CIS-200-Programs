﻿// Program 2
// CIS 200-01
// Fall 2016
// Due: 11/1/16
// By: C1816

// File: AddressForm.cs
// Class creates Add Address dialog box form GUI. Performs validation 
// and provides string properties for each field.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class AddressForm : Form
    {
        // Precondition: List stateList populated with available states
        // Postcondition: Form's GUI prepared for display
        public AddressForm()
        {
            InitializeComponent();
        }

        internal string AddressName
        {
            // Precondition: None
            // Postcondition: Text of form's Name field returned
            get
            {
                return nameTxtBx.Text;
            }

            // Precondtion: None
            // Postcondition: Text of form's Name field set to specifed value
            set
            {
                nameTxtBx.Text = value;
            }
        }

        internal string Address1
        {
            // Precondition: None
            // Postcondition: Text of form's Address1 field returned
            get
            {
                return address1TxtBx.Text;
            }
            
            // Precondition: None
            // Postcondtiion: Text of form's Address1 field set to specified value
            set
            {
                address1TxtBx.Text = value;
            }
        }

        internal string Address2
        {
            // Precondition: None
            // Postcondition: Text of form's Address2 field returned
            get
            {
                return address2TxtBx.Text;
            }

            // Precondition: None
            // Postcondtiion: Text of form's Address2 field set to specified value
            set
            {
                address2TxtBx.Text = value;
            }
        }

        internal string City
        {
            // Precondition: None
            // Postcondition: Text of form's City field returned
            get
            {
                return cityTxtBx.Text;
            }

            // Precondition: None
            // Postcondtiion: Text of form's City field set to specified value
            set
            {
                cityTxtBx.Text = value;
            }
        }

        internal string State
        {
            // Precondition: None
            // Postcondition: State combo box's selected item converted to string
            get
            {
                return stateComboBx.SelectedItem.ToString();
            }
        }

        public string Zip
        {
            // Precondition: None
            // Postcondition: Text of form's Zip field returned
            get
            {
                return zipTxtBx.Text;
            }

            // Precondition: None
            // Postcondtiion: Text of form's Zip field set to specified value
            set
            {
                zipTxtBx.Text = value;
            }
        }

        // Precondition: Focus shifts from nameTxtBx
        // Postcondition: If text is invalid, focus remains on nameTxtBx
        //                and error provider highlights the field
        private void nameTxtBox_Validating(object sender, CancelEventArgs e)
        {
            if (nameTxtBx.TextLength == 0)  // If field is empty
            {
                e.Cancel = true;
                nameErrorProvider.SetError(nameTxtBx, "Must provide Name");
            }
        }

        // Precondtion: Validating of nameTxtBx isn't canceled, data is okay
        // Postocndition: Error provider cleared and focus is okay to change
        private void nameTxtBox_Validated(object sender, EventArgs e)
        {
            nameErrorProvider.SetError(nameTxtBx, "");
        }
        
        // Precondition: Focus shifts from address1TxtBx
        // Postcondition: If text is invalid, focus remains on address1TxtBx
        //                and error provider highlights the field
        private void address1TxtBx_Validating(object sender, CancelEventArgs e)
        {
            if (address1TxtBx.TextLength == 0)  // If field is empty
            {
                e.Cancel = true;
                address1ErrorProvider.SetError(address1TxtBx, "Must provide Address");
            }
        }

        // Precondtion: Validating of address1TxtBx isn't canceled, data is okay
        // Postocndition: Error provider cleared and focus is okay to change
        private void address1TxtBx_Validated(object sender, EventArgs e)
        {
            address1ErrorProvider.SetError(address1TxtBx, "");
        }


        // Precondition: Focus shifts from cityTxtBx
        // Postcondition: If text is invalid, focus remains on cityTxtBx
        //                and error provider highlights the field
        private void cityTxtBx_Validating(object sender, CancelEventArgs e)
        {
            if (cityTxtBx.TextLength == 0)  // If field is empty
            {
                e.Cancel = true;
                cityErrorProvider.SetError(cityTxtBx, "Must provide City");
            }
        }

        // Precondtion: Validating of cityTxtBx isn't canceled, data is okay
        // Postcondition: Error provider cleared and focus is okay to change
        private void cityTxtBx_Validated(object sender, EventArgs e)
        {
            cityErrorProvider.SetError(cityTxtBx, ""); // If field is empty
        }

        // Precondition:  Focus is shifting from stateComboBx
        // Postcondition: If selection invalid, focus remains and error provider
        //                highlights the field
        private void stateComboBx_Validating(object sender, CancelEventArgs e)
        {
            if(stateComboBx.SelectedIndex == -1) // Nothing is selected
            {
                e.Cancel = true;
                stateErrorProvider.SetError(stateComboBx, "Must select State");
            }
        }

        // Precondition: Validating of stateComboBx not cancelled, data is okay
        // Postcondition: Error provider cleared, focus allowed to change
        private void stateComboBx_Validated(object sender, EventArgs e)
        {
            stateErrorProvider.SetError(stateComboBx, "");
        }

        // Precondition:  Focus is shifting from zipTxtBx
        // Postcondition: If selection invalid, focus remains and error provider
        //                highlights the field
        private void zipTxtBx_Validating(object sender, CancelEventArgs e)
        {
            int zip;    // Variable to hold the zip code
            const int MIN_ZIP = 00000;
            const int MAX_ZIP = 99999;

            if (cityTxtBx.TextLength == 0)
            {
                e.Cancel = true;
                zipErrorProvider.SetError(zipTxtBx, "Must provide Zip");
            }

            else if(int.TryParse(zipTxtBx.Text, out zip)) // Parse zipTxtBx's text) // If field is empty
            {
                // Test if zip is within desired range
                if (zip >= MIN_ZIP && zip <= MAX_ZIP)
                {
                    zipErrorProvider.SetError(zipTxtBx, "");
                }
                else
                {
                    e.Cancel = true;
                    zipErrorProvider.SetError(zipTxtBx, "Zip must be between 00000 and 99999");
                }
            }
        }

        // Precondition: Validating of zipComboBx not cancelled, data is okay
        // Postcondition: Error provider cleared, focus allowed to change
        private void zipTxtBx_Validated(object sender, EventArgs e)
        {
            zipErrorProvider.SetError(zipTxtBx, "");
        }

        // Precondition: User clicked on okBtn
        // Postcondition: If there is an invalid field on the dialog box,
        //                keeps form open and gives first invalid field the focus.
        //                Otherwise, returns okay and closes the form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            if (ValidateChildren()) // If all controls validate
                this.DialogResult = DialogResult.OK;    // Form closes and returns "OK"
        }

        // Precondition: User pressed cancelBtn
        // Postcondition: Form closes and sends Cancel
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // left-click
                this.DialogResult = DialogResult.Cancel; // exit form
        }
    }
}
