﻿namespace UPVApp
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nameLbl = new System.Windows.Forms.Label();
            this.address1Lbl = new System.Windows.Forms.Label();
            this.address2Lbl = new System.Windows.Forms.Label();
            this.cityLbl = new System.Windows.Forms.Label();
            this.stateLbl = new System.Windows.Forms.Label();
            this.zipLbl = new System.Windows.Forms.Label();
            this.nameTxtBx = new System.Windows.Forms.TextBox();
            this.address1TxtBx = new System.Windows.Forms.TextBox();
            this.address2TxtBx = new System.Windows.Forms.TextBox();
            this.cityTxtBx = new System.Windows.Forms.TextBox();
            this.stateComboBx = new System.Windows.Forms.ComboBox();
            this.zipTxtBx = new System.Windows.Forms.TextBox();
            this.okBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.nameErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.address1ErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.cityErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.stateErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.zipErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nameErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.address1ErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zipErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(64, 27);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(70, 25);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Name:";
            this.nameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // address1Lbl
            // 
            this.address1Lbl.AutoSize = true;
            this.address1Lbl.Location = new System.Drawing.Point(30, 83);
            this.address1Lbl.Name = "address1Lbl";
            this.address1Lbl.Size = new System.Drawing.Size(107, 25);
            this.address1Lbl.TabIndex = 1;
            this.address1Lbl.Text = "Address 1:";
            this.address1Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // address2Lbl
            // 
            this.address2Lbl.AutoSize = true;
            this.address2Lbl.Location = new System.Drawing.Point(30, 139);
            this.address2Lbl.Name = "address2Lbl";
            this.address2Lbl.Size = new System.Drawing.Size(107, 25);
            this.address2Lbl.TabIndex = 2;
            this.address2Lbl.Text = "Address 2:";
            this.address2Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cityLbl
            // 
            this.cityLbl.AutoSize = true;
            this.cityLbl.Location = new System.Drawing.Point(82, 195);
            this.cityLbl.Name = "cityLbl";
            this.cityLbl.Size = new System.Drawing.Size(52, 25);
            this.cityLbl.TabIndex = 3;
            this.cityLbl.Text = "City:";
            this.cityLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Location = new System.Drawing.Point(73, 251);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(64, 25);
            this.stateLbl.TabIndex = 4;
            this.stateLbl.Text = "State:";
            this.stateLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zipLbl
            // 
            this.zipLbl.AutoSize = true;
            this.zipLbl.Location = new System.Drawing.Point(89, 310);
            this.zipLbl.Name = "zipLbl";
            this.zipLbl.Size = new System.Drawing.Size(45, 25);
            this.zipLbl.TabIndex = 5;
            this.zipLbl.Text = "Zip:";
            this.zipLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // nameTxtBx
            // 
            this.nameTxtBx.Location = new System.Drawing.Point(152, 24);
            this.nameTxtBx.Name = "nameTxtBx";
            this.nameTxtBx.Size = new System.Drawing.Size(369, 29);
            this.nameTxtBx.TabIndex = 6;
            this.nameTxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.nameTxtBox_Validating);
            this.nameTxtBx.Validated += new System.EventHandler(this.nameTxtBox_Validated);
            // 
            // address1TxtBx
            // 
            this.address1TxtBx.Location = new System.Drawing.Point(152, 80);
            this.address1TxtBx.Name = "address1TxtBx";
            this.address1TxtBx.Size = new System.Drawing.Size(369, 29);
            this.address1TxtBx.TabIndex = 7;
            this.address1TxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.address1TxtBx_Validating);
            this.address1TxtBx.Validated += new System.EventHandler(this.address1TxtBx_Validated);
            // 
            // address2TxtBx
            // 
            this.address2TxtBx.Location = new System.Drawing.Point(152, 136);
            this.address2TxtBx.Name = "address2TxtBx";
            this.address2TxtBx.Size = new System.Drawing.Size(369, 29);
            this.address2TxtBx.TabIndex = 8;
            // 
            // cityTxtBx
            // 
            this.cityTxtBx.Location = new System.Drawing.Point(152, 192);
            this.cityTxtBx.Name = "cityTxtBx";
            this.cityTxtBx.Size = new System.Drawing.Size(369, 29);
            this.cityTxtBx.TabIndex = 9;
            this.cityTxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.cityTxtBx_Validating);
            this.cityTxtBx.Validated += new System.EventHandler(this.cityTxtBx_Validated);
            // 
            // stateComboBx
            // 
            this.stateComboBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stateComboBx.FormattingEnabled = true;
            this.stateComboBx.Items.AddRange(new object[] {
            "KY",
            "CA",
            "NY",
            "TX"});
            this.stateComboBx.Location = new System.Drawing.Point(152, 248);
            this.stateComboBx.MaxDropDownItems = 50;
            this.stateComboBx.Name = "stateComboBx";
            this.stateComboBx.Size = new System.Drawing.Size(369, 32);
            this.stateComboBx.TabIndex = 10;
            this.stateComboBx.Validating += new System.ComponentModel.CancelEventHandler(this.stateComboBx_Validating);
            this.stateComboBx.Validated += new System.EventHandler(this.stateComboBx_Validated);
            // 
            // zipTxtBx
            // 
            this.zipTxtBx.Location = new System.Drawing.Point(152, 307);
            this.zipTxtBx.Name = "zipTxtBx";
            this.zipTxtBx.Size = new System.Drawing.Size(369, 29);
            this.zipTxtBx.TabIndex = 11;
            this.zipTxtBx.Validating += new System.ComponentModel.CancelEventHandler(this.zipTxtBx_Validating);
            this.zipTxtBx.Validated += new System.EventHandler(this.zipTxtBx_Validated);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(35, 373);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(222, 66);
            this.okBtn.TabIndex = 12;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(299, 373);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(222, 66);
            this.cancelBtn.TabIndex = 13;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // nameErrorProvider
            // 
            this.nameErrorProvider.ContainerControl = this;
            // 
            // address1ErrorProvider
            // 
            this.address1ErrorProvider.ContainerControl = this;
            // 
            // cityErrorProvider
            // 
            this.cityErrorProvider.ContainerControl = this;
            // 
            // stateErrorProvider
            // 
            this.stateErrorProvider.ContainerControl = this;
            // 
            // zipErrorProvider
            // 
            this.zipErrorProvider.ContainerControl = this;
            // 
            // AddressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 477);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.zipTxtBx);
            this.Controls.Add(this.stateComboBx);
            this.Controls.Add(this.cityTxtBx);
            this.Controls.Add(this.address2TxtBx);
            this.Controls.Add(this.address1TxtBx);
            this.Controls.Add(this.nameTxtBx);
            this.Controls.Add(this.zipLbl);
            this.Controls.Add(this.stateLbl);
            this.Controls.Add(this.cityLbl);
            this.Controls.Add(this.address2Lbl);
            this.Controls.Add(this.address1Lbl);
            this.Controls.Add(this.nameLbl);
            this.Name = "AddressForm";
            this.Text = "Address Form";
            ((System.ComponentModel.ISupportInitialize)(this.nameErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.address1ErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zipErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label address1Lbl;
        private System.Windows.Forms.Label address2Lbl;
        private System.Windows.Forms.Label cityLbl;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label zipLbl;
        private System.Windows.Forms.TextBox nameTxtBx;
        private System.Windows.Forms.TextBox address1TxtBx;
        private System.Windows.Forms.TextBox address2TxtBx;
        private System.Windows.Forms.TextBox cityTxtBx;
        private System.Windows.Forms.ComboBox stateComboBx;
        private System.Windows.Forms.TextBox zipTxtBx;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ErrorProvider nameErrorProvider;
        private System.Windows.Forms.ErrorProvider address1ErrorProvider;
        private System.Windows.Forms.ErrorProvider cityErrorProvider;
        private System.Windows.Forms.ErrorProvider stateErrorProvider;
        private System.Windows.Forms.ErrorProvider zipErrorProvider;
    }
}