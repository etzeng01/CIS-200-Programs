﻿// Program 2
// CIS 200-01
// Fall 2016
// Due: 11/1/16
// By: C1816

// File: Prog2Form.cs
// Class creates main GUI for Program 2. Provides File menu with
// About and Exit items, an Insert menu with Address and Letter items,
// and a Report menu with List Address and List Parcels items.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        private UserParcelView upv; // The UserParcelView

        // Precondition: None
        // Postcondition: Form's GUI prepared for display. Few test addresses added to list of addresses. 
        public Prog2Form()
        {
            InitializeComponent();

            upv = new UserParcelView(); // Create User Parcel View

            // Test Data - Magic Numbers OK
            upv.AddAddress("John Smith", "123 Any St.", "Apt. 45",
              "Louisville", "KY", 40202); // Test Address 1
            upv.AddAddress("Jane Doe", "987 Main St.", "",
                "Beverly Hills", "CA", 90210); // Test Address 2
            upv.AddAddress("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            upv.AddAddress("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            upv.AddAddress("John Doe", "111 Market St.", "",
                "Jeffersonville", "IN", 47130); // Test Address 5
            upv.AddAddress("Jane Smith", "55 Hollywood Blvd.", "Apt. 9",
                "Los Angeles", "CA", 90212); // Test Address 6
            upv.AddAddress("Captain Robert Crunch", "21 Cereal Rd.", "Room 987",
                "Bethesda", "MD", 20810); // Test Address 7
            upv.AddAddress("Vlad Dracula", "6543 Vampire Way", "Apt. 1",
                "Bloodsucker City", "TN", 37210); // Test Address 8

            upv.AddLetter(upv.AddressAt(1), upv.AddressAt(2), 3.95M);
            upv.AddLetter(upv.AddressAt(2), upv.AddressAt(3), 4.25M);
            upv.AddGroundPackage(upv.AddressAt(4), upv.AddressAt(5), 14, 10, 20, 30);
            upv.AddGroundPackage(upv.AddressAt(6), upv.AddressAt(7), 10, 11, 12, 13);
            upv.AddNextDayAirPackage(upv.AddressAt(7), upv.AddressAt(6), 10, 12, 14, 16, 30M);
            upv.AddNextDayAirPackage(upv.AddressAt(6), upv.AddressAt(5), 11, 12, 13, 14, 10M);
            upv.AddTwoDayAirPackage(upv.AddressAt(2), upv.AddressAt(3), 12, 14, 16, 17, TwoDayAirPackage.Delivery.Saver);
            upv.AddTwoDayAirPackage(upv.AddressAt(4), upv.AddressAt(5), 18, 10, 39, 29, TwoDayAirPackage.Delivery.Early);
        }

        // Precondition: File, About menu item activated
        // Postcondition: Information about author displayed in dialog box
        private void aboutFileMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(String.Format("Program 2{0}By: C1814{0}" +
                "CIS 200-01{0}Fall 2016", System.Environment.NewLine), "About Program 2");
        }

        // Precondition: Application is running and Exit from the File menu has been clicked
        // Postcondition: Application terminates 
        private void exitFileMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Precondition: Report, List Addresses menu item activated
        // Postcondition: 
        private void listAddressesReportMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report

            List<Address> addresses; // List of addresses

            addresses = upv.AddressList;

            result.Append(String.Format("Address List"));
            result.Append(System.Environment.NewLine);
            result.Append(System.Environment.NewLine);

            foreach (Address a in addresses)
            {
                result.Append(a.ToString());
                result.Append(System.Environment.NewLine);
                result.Append(System.Environment.NewLine);
            }

            reportTxtBx.Text = result.ToString();
        }

        // Precondition: Report, Parcel menu item activated
        // Postcondition: List of parcels displayed in the reportTxtBx TextBox
        private void listParcelsReportMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report

            List<Parcel> parcels; // List of parcels

            parcels = upv.ParcelList;

            decimal totalcost = 0;

            // LINQ: selects letter items
            // var letters =}
            //    from p in parcels
            //    let letter = p as Letter // Downcast if Letter, null otherwise
            //    where letter != null
            //     select letter;

            result.Append(String.Format("Parcel List"));
            result.Append(System.Environment.NewLine);
            result.Append(System.Environment.NewLine);

            foreach (Parcel p in parcels)
            {
                result.Append(p.ToString());
                result.Append(System.Environment.NewLine);
                result.Append(System.Environment.NewLine);
                totalcost += p.CalcCost();
            }

            reportTxtBx.Text = result.ToString() + 
                "==========" +
                System.Environment.NewLine + 
                System.Environment.NewLine + 
                "Total Cost: " + 
                totalcost.ToString("C");
        }

        // Precondition: Insert, Address menu item activated
        // Postcondition: Address dialog box displayed. If data entered
        //                is valid, Address is created and added to library
        private void addressInsertMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm();

            DialogResult result = addressForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                try
                {
                    upv.AddAddress(addressForm.AddressName, addressForm.Address1,
                        addressForm.Address2, addressForm.City, addressForm.State,     // Fix me!
                        int.Parse(addressForm.Zip));
                }
                catch
                {
                    MessageBox.Show("Problem with address validation! Please try again.", "Validation Error");
                }
            }
        }

        // Precondition: Insert, Letter menu item activated
        // Postcondition: Dialog box appears where user can choose letter information
        private void letterInsertMenuItem_Click(object sender, EventArgs e)
        {
            List<Address> addresses; // List of addresses

            addresses = upv.AddressList;

            if (addresses.Count() == 0) // Must have addresses
                MessageBox.Show("Must have addresses", "Address Error");
            else
            {
                LetterForm letterForm = new LetterForm(addresses);

                DialogResult result = letterForm.ShowDialog();  // Show form as dialog, store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    try
                    {
                        upv.AddLetter(upv.AddressAt(letterForm.OriginIndex),
                        upv.AddressAt(letterForm.DestinationIndex),
                        decimal.Parse(letterForm.FixedCost));

                    }
                    catch
                    {
                        MessageBox.Show("Problem with letter validation! Please try again.", "Validation Error");
                    }
                }
            }
        }
    }
}
